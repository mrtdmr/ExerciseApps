﻿namespace ExtensionMethodsProject
{
    public class Distance
    {
        public int XDistance { get; set; }

        public int YDistance { get; set; }
    }
}